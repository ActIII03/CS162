#include <stdio.h> 
#include <stdlib.h>
#include <math.h> 

void greet_user();
char * read_in_set(int * set_size);
void printPowerSet(char * set, int set_size);
void binary_relation(int * jth_element, int bin_counter, int set_size, char *set);

