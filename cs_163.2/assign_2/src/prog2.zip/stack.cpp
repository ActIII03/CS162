//Name: Armant Touche
//Class: CS 163
//Instructor: Karla Fant
//Description:

#include "stack.h"

stack::stack()
{
    head = NULL;
    top_index = 0;
    MAX = 5;
}

stack::~stack()
{

}

int stack::push(routes & new_route)
{
    //Empty list
    if(!head)
    {
        head = new node;
        head -> route_entries = new routes[MAX];
        head -> next = NULL;
        head -> route_entries[top_index].copy_route(new_route);
        ++top_index;
    }
    else if(top_index < MAX)
    {
        head -> route_entries[top_index].copy_route(new_route);
        ++top_index;
    }
    else
    {
        top_index = 0;
        node * temp = head;
        head = new node;
        head -> route_entries = new routes[MAX];
        head -> next = temp;
        head -> route_entries[top_index].copy_route(new_route);
        ++top_index;
    }

    return top_index;
}


int stack::pop(routes & return_route)
{
    return 0;
}
