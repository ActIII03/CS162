# Program 2: Game Management System
## Name: Armant Touche

### Requirement:
* Make
* GCC
* C++ Libs

### To compile and run:
* $ make
* $ ./game

