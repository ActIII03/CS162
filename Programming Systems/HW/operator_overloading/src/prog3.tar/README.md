# Program 3: FishBowl
## Name: Armant Touche

### Requirement:
* Make
* GCC
* C++ Libs

### To compile and run:
* $ make
* $ ./fishbowl

