//Name: Armant
//Class: CS 163
//Instructor: Karla Fant
//Description: This is the client's interface where Trivial Pursuit Game takes place
#include <iostream>
#include <fstream>
#include <cstdlib>
#include "stack_and_queue.h"

using namespace std;

const int BUFFER = 300;


//The Game 
class trivial_pursuit
{
    public:

        int get_txt(char q_1[], char q_2[], char q_3[], char a_1[], char a_2[], char a_3[]);
        int get_answer();
        bool is_correct(char answer[]);

    private:
        
        //Update constructor
        stack new_q_a;
        stack player_stack; 
        stack discard_stack;
};
