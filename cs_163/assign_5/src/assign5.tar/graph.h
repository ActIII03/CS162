//Name: Armant Touche
//Class: CS 163
//Instructor: Karls Fant
//Description:

#include "tasks_list.h"


struct vertex
{
    TasksToDo * new_task;
    struct node * head;
};

struct node
{
    node();
    vertex * adjacent;
    node * next;
};

class table
{
    public:
        
        //Constructor and Destructor
        table(int size = 15);
        ~table();
        
        //Insert vertex
        int insert_vertex(TasksToDo & new_task);

        //Find location
        int find_location(char * key);

        //Insert path
        int insert_path(char * task, char * connect_to);

        //Display All tasks
        int display_all();

    private:

        vertex * adjacency_list;
        int list_size;
        int num_of_tasks;

        //Recursive function
        //Display adjacent paths
        void display_recursive(node * head);
};
