#include "cs162_list.h"

int main()
{
    activity_type temp_act;
    list list_mgmt;

    //greetings();
    //Place Menu foo here
    temp_act.read_in(temp_act);

    return 0;
}

